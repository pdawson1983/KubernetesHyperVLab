#!/bin/bash
# =============================================================================
# test-local.sh
# Tests the claude-agent image locally before pushing to the cluster registry.
# Run this from WSL before doing podman push.
#
# Usage:
#   chmod +x test-local.sh
#   ANTHROPIC_API_KEY=sk-ant-xxx ./test-local.sh
# =============================================================================

set -euo pipefail

IMAGE="claude-agent:latest"
TEST_DIR=$(mktemp -d /tmp/claude-agent-test-XXXXXX)

log() { echo "[test] $*"; }
pass() { echo "[PASS] $*"; }
fail() { echo "[FAIL] $*"; exit 1; }

cleanup() {
  log "Cleaning up test directory: $TEST_DIR"
  rm -rf "$TEST_DIR"
  podman rm -f claude-agent-test 2>/dev/null || true
}
trap cleanup EXIT

# ── Check prerequisites ───────────────────────────────────────────────────────

[ -z "${ANTHROPIC_API_KEY:-}" ] && fail "Set ANTHROPIC_API_KEY before running"
command -v podman >/dev/null || fail "podman not installed"

log "Using test directory: $TEST_DIR"

# ── Build the image ───────────────────────────────────────────────────────────

log "Building image: $IMAGE"
podman build -t "$IMAGE" . || fail "Build failed"
pass "Image built successfully"

# ── Set up test memory layout ─────────────────────────────────────────────────

mkdir -p \
  "$TEST_DIR/memory/inbox" \
  "$TEST_DIR/memory/specs" \
  "$TEST_DIR/memory/queue" \
  "$TEST_DIR/memory/workspace" \
  "$TEST_DIR/memory/reviews" \
  "$TEST_DIR/memory/deployments" \
  "$TEST_DIR/memory/logs" \
  "$TEST_DIR/agent-config"

# Write a test inbox payload (what the user would submit)
cat > "$TEST_DIR/memory/inbox/test-task-001.json" << 'EOF'
{
  "event": "issue.opened",
  "title": "Add a hello world endpoint",
  "body": "Create a simple GET /hello endpoint that returns {\"message\": \"Hello, World!\"}",
  "labels": ["feature"],
  "submitted_at": "2026-05-07T00:00:00Z"
}
EOF

# Write architect agent config
cat > "$TEST_DIR/agent-config/config.json" << 'EOF'
{
  "role": "architect",
  "maxTokens": 2048,
  "triggers": ["issue.opened"],
  "timeout": 120
}
EOF

# Write architect instructions
cat > "$TEST_DIR/agent-config/CLAUDE.md" << 'EOF'
## Role: Architect Agent

You are a software architect. Analyze the incoming request and produce a clear spec.

## Responsibilities
- Read the incoming request from /memory/inbox/
- Write a concise spec to /memory/specs/spec-001.md
- Write {"ready": true, "spec": "/memory/specs/spec-001.md"} to /memory/queue/coder.json

## Rules
- Keep specs under 200 lines
- Always include: Overview, Components, API contracts, Acceptance criteria
- Never write implementation code
EOF

# Write project context
cat > "$TEST_DIR/memory/CLAUDE.md" << 'EOF'
# Test Project Context

## Stack
- Node.js REST API
- Express framework
- Tests with Jest

## Conventions
- Routes in /src/routes/
- Tests next to source files as *.test.js
EOF

log "Test environment set up"

# ── Run the architect agent ───────────────────────────────────────────────────

log "Running architect agent (this will call the Anthropic API)..."

podman run --rm \
  --name claude-agent-test \
  -e ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  -e AGENT_ROLE="architect" \
  -e MEMORY_PATH="/memory" \
  -e MAX_TOKENS="2048" \
  -e AGENT_TIMEOUT="120" \
  -v "$TEST_DIR/memory:/memory" \
  -v "$TEST_DIR/agent-config:/etc/agent:ro" \
  "$IMAGE" \
  || fail "Agent container exited with error"

pass "Agent container completed successfully"

# ── Validate outputs ──────────────────────────────────────────────────────────

log "Checking outputs..."

# Check spec was written
if ls "$TEST_DIR/memory/specs/"*.md 1>/dev/null 2>&1; then
  SPEC_FILE=$(ls "$TEST_DIR/memory/specs/"*.md | head -1)
  SPEC_SIZE=$(wc -c < "$SPEC_FILE")
  pass "Spec written: $SPEC_FILE ($SPEC_SIZE bytes)"
  echo "--- Spec preview (first 20 lines) ---"
  head -20 "$SPEC_FILE"
  echo "---"
else
  fail "No spec file found in $TEST_DIR/memory/specs/"
fi

# Check coder trigger was written
if [ -f "$TEST_DIR/memory/queue/coder.json" ]; then
  pass "Coder trigger written: $(cat "$TEST_DIR/memory/queue/coder.json")"
else
  fail "No coder trigger found at $TEST_DIR/memory/queue/coder.json"
fi

# Check log was written
if ls "$TEST_DIR/memory/logs/"*.log 1>/dev/null 2>&1 || ls "$TEST_DIR/memory/logs/"*.md 1>/dev/null 2>&1; then
  pass "Log files written"
else
  fail "No log files found in $TEST_DIR/memory/logs/"
fi

echo ""
echo "================================================"
echo "  All tests passed!"
echo "  Memory output is at: $TEST_DIR/memory/"
echo "  Inspect with: ls -la $TEST_DIR/memory/**"
echo "================================================"
